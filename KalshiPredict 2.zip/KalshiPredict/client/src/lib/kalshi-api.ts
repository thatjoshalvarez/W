// Kalshi API integration for fetching real market data
// Note: In production, this would use the actual Kalshi API

export interface KalshiMarket {
  id: string;
  ticker: string;
  title: string;
  subtitle?: string;
  category: string;
  yes_price?: number;
  no_price?: number;
  volume_24h?: number;
  open_interest?: number;
  close_time?: string;
  status: string;
}

export interface KalshiEvent {
  id: string;
  title: string;
  category: string;
  markets: KalshiMarket[];
}

class KalshiAPI {
  private baseUrl = 'https://trading-api.kalshi.com/v1';
  private demoUrl = 'https://demo-api.kalshi.co/trade-api/v2';
  private useDemoMode = true; // Set to true for demo mode

  private getApiUrl() {
    return this.useDemoMode ? this.demoUrl : this.baseUrl;
  }

  async getExchangeStatus() {
    try {
      const response = await fetch(`${this.getApiUrl()}/exchange/status`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching exchange status:', error);
      throw error;
    }
  }

  async getMarkets(limit = 100, cursor?: string) {
    try {
      const url = new URL(`${this.getApiUrl()}/markets`);
      url.searchParams.set('limit', limit.toString());
      if (cursor) {
        url.searchParams.set('cursor', cursor);
      }

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching markets:', error);
      throw error;
    }
  }

  async getMarket(ticker: string) {
    try {
      const response = await fetch(`${this.getApiUrl()}/markets/${ticker}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching market:', error);
      throw error;
    }
  }

  async getEvents(limit = 100) {
    try {
      const url = new URL(`${this.getApiUrl()}/events`);
      url.searchParams.set('limit', limit.toString());

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching events:', error);
      throw error;
    }
  }

  async getMarketHistory(ticker: string, min_ts?: number, max_ts?: number) {
    try {
      const url = new URL(`${this.getApiUrl()}/markets/${ticker}/history`);
      if (min_ts) url.searchParams.set('min_ts', min_ts.toString());
      if (max_ts) url.searchParams.set('max_ts', max_ts.toString());

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching market history:', error);
      throw error;
    }
  }

  // Calculate PredictWise score based on various factors
  calculatePredictWiseScore(market: KalshiMarket, fairValue: number): number {
    const currentPrice = market.yes_price || 50;
    const volume = market.volume_24h || 0;
    const openInterest = market.open_interest || 0;
    
    // Value score (0-4): How good the price is vs fair value
    const priceDiff = Math.abs(currentPrice - fairValue);
    const valueScore = Math.max(0, 4 - (priceDiff / 10));
    
    // Liquidity score (0-3): Based on volume and open interest
    const liquidityScore = Math.min(3, (volume + openInterest) / 100000);
    
    // Time score (0-3): Time until resolution (placeholder)
    const timeScore = 2.5; // Would calculate based on close_time
    
    const totalScore = valueScore + liquidityScore + timeScore;
    return Math.min(10, Math.max(0, totalScore));
  }

  // Determine value assessment
  getValueAssessment(currentPrice: number, fairValue: number): 'good_value' | 'fair_value' | 'overpriced' {
    const diff = currentPrice - fairValue;
    if (diff > 5) return 'overpriced';
    if (diff < -3) return 'good_value';
    return 'fair_value';
  }
}

export const kalshiAPI = new KalshiAPI();
