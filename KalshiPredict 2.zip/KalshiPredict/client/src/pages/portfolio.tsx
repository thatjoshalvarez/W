import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Header } from '@/components/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { ExternalLink, Plus, TrendingUp, TrendingDown, DollarSign, Target } from 'lucide-react';

interface Position {
  id: string;
  marketTitle: string;
  ticker: string;
  position: 'yes' | 'no';
  shares: number;
  entryPrice: number;
  currentPrice: number;
  value: number;
  pnl: number;
  pnlPercent: number;
}

export default function Portfolio() {
  const { user, isPro } = useAuth();
  const { toast } = useToast();
  const [portfolioUrl, setPortfolioUrl] = useState('');
  const [isLinked, setIsLinked] = useState(false);

  // Demo portfolio data
  const positions: Position[] = [
    {
      id: '1',
      marketTitle: 'Will Bitcoin reach $100,000 by end of 2024?',
      ticker: 'BTC-100K-2024',
      position: 'yes',
      shares: 250,
      entryPrice: 0.45,
      currentPrice: 0.42,
      value: 105,
      pnl: -7.50,
      pnlPercent: -6.67
    },
    {
      id: '2',
      marketTitle: 'Will the Fed cut rates by 0.25% in December 2024?',
      ticker: 'FED-23DEC-T3.00',
      position: 'no',
      shares: 150,
      entryPrice: 0.35,
      currentPrice: 0.33,
      value: 49.50,
      pnl: -3.00,
      pnlPercent: -5.71
    },
    {
      id: '3',
      marketTitle: 'Will Taylor Swift attend the Super Bowl?',
      ticker: 'TAYLOR-SUPERBOWL-2025',
      position: 'yes',
      shares: 100,
      entryPrice: 0.71,
      currentPrice: 0.73,
      value: 73,
      pnl: 2.00,
      pnlPercent: 2.82
    }
  ];

  const totalValue = positions.reduce((sum, pos) => sum + pos.value, 0);
  const totalPnL = positions.reduce((sum, pos) => sum + pos.pnl, 0);
  const totalPnLPercent = totalValue > 0 ? (totalPnL / (totalValue - totalPnL)) * 100 : 0;

  const handleLinkPortfolio = () => {
    if (!portfolioUrl.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter your Kalshi portfolio URL.",
        variant: "destructive",
      });
      return;
    }

    if (!portfolioUrl.includes('kalshi.com')) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid Kalshi portfolio URL.",
        variant: "destructive",
      });
      return;
    }

    setIsLinked(true);
    toast({
      title: "Portfolio Linked!",
      description: "Your Kalshi portfolio has been connected to MarketEdge.",
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercent = (percent: number) => {
    return `${percent > 0 ? '+' : ''}${percent.toFixed(2)}%`;
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Portfolio Tracking</h1>
          <p className="text-gray-600 mb-8">Sign in to track your prediction market positions</p>
          <Button data-testid="button-sign-in">Sign In</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Portfolio</h1>
          <p className="text-gray-600">Track your prediction market positions and performance</p>
        </div>

        {!isPro && (
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-blue-50 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Unlock Advanced Portfolio Features</h3>
                  <p className="text-gray-600 text-sm">Get real-time portfolio tracking, advanced analytics, and more with Pro.</p>
                </div>
                <Button data-testid="button-upgrade-portfolio">
                  Upgrade to Pro
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Link Portfolio Section */}
        {!isLinked ? (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ExternalLink className="mr-2" size={20} />
                Link Your Kalshi Portfolio
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Connect your Kalshi account to automatically track your positions and get MarketEdge insights.
                </p>
                <div className="flex space-x-2">
                  <Input
                    placeholder="https://kalshi.com/portfolio/username"
                    value={portfolioUrl}
                    onChange={(e) => setPortfolioUrl(e.target.value)}
                    className="flex-1"
                    data-testid="input-portfolio-url"
                  />
                  <Button onClick={handleLinkPortfolio} data-testid="button-link-portfolio">
                    <Plus className="mr-2" size={16} />
                    Link Portfolio
                  </Button>
                </div>
                <p className="text-xs text-gray-500">
                  Note: This demo shows sample data. Real integration would require Kalshi API access.
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Portfolio Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Value</p>
                      <p className="text-2xl font-bold">{formatCurrency(totalValue)}</p>
                    </div>
                    <DollarSign className="text-primary" size={24} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total P&L</p>
                      <p className={`text-2xl font-bold ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(totalPnL)}
                      </p>
                    </div>
                    {totalPnL >= 0 ? (
                      <TrendingUp className="text-green-600" size={24} />
                    ) : (
                      <TrendingDown className="text-red-600" size={24} />
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Return %</p>
                      <p className={`text-2xl font-bold ${totalPnLPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatPercent(totalPnLPercent)}
                      </p>
                    </div>
                    <Target className="text-primary" size={24} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Positions</p>
                      <p className="text-2xl font-bold">{positions.length}</p>
                    </div>
                    <Target className="text-primary" size={24} />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Positions List */}
            <Card>
              <CardHeader>
                <CardTitle>Active Positions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {positions.map((position) => (
                    <div key={position.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{position.marketTitle}</h3>
                        <Badge variant={position.position === 'yes' ? 'default' : 'secondary'}>
                          {position.position.toUpperCase()}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Shares</p>
                          <p className="font-medium">{position.shares}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Entry Price</p>
                          <p className="font-medium">{formatCurrency(position.entryPrice)}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Current Price</p>
                          <p className="font-medium">{formatCurrency(position.currentPrice)}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Value</p>
                          <p className="font-medium">{formatCurrency(position.value)}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">P&L</p>
                          <p className={`font-medium ${position.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(position.pnl)}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600">Return %</p>
                          <p className={`font-medium ${position.pnlPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatPercent(position.pnlPercent)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}