import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Header } from '@/components/header';
import { StatsOverview } from '@/components/stats-overview';
import { SubscriptionPrompt } from '@/components/subscription-prompt';
import { MarketFilters } from '@/components/market-filters';
import { MarketCard } from '@/components/market-card';
import { MarketModal } from '@/components/market-modal';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import { Link, useLocation } from 'wouter';
import { Loader2, BarChart3, Users, Wallet, User } from 'lucide-react';
import type { Market } from '@shared/schema';

export default function Home() {
  const { user, updateUser, isPro } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMarket, setSelectedMarket] = useState<Market | null>(null);
  const [filters, setFilters] = useState({
    categories: [] as string[],
    valueAssessment: 'all',
    scoreRange: [0, 10],
  });
  const [sortBy, setSortBy] = useState('score');
  const [scoresUsedInSession, setScoresUsedInSession] = useState<string[]>([]);

  const { data: markets, isLoading: marketsLoading } = useQuery({
    queryKey: ['/api/markets'],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append('search', searchQuery);
      if (filters.categories.length > 0) params.append('category', filters.categories[0]);
      params.append('limit', '50');
      
      const response = await fetch(`/api/markets?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch markets');
      return response.json();
    },
    refetchInterval: 30000,
  });

  const useScoreMutation = useMutation({
    mutationFn: async ({ userId, marketId }: { userId: string; marketId: string }) => {
      const response = await apiRequest('POST', '/api/use-score', { userId, marketId });
      return response.json();
    },
    onSuccess: (data) => {
      updateUser({ dailyScoresUsed: data.dailyScoresUsed });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Score Revealed",
        description: "MarketEdge score has been calculated for this market.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Score Request Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Sync markets on component mount
  useEffect(() => {
    const syncMarkets = async () => {
      try {
        await apiRequest('POST', '/api/sync-markets', {});
        queryClient.invalidateQueries({ queryKey: ['/api/markets'] });
      } catch (error) {
        console.error('Failed to sync markets:', error);
      }
    };

    syncMarkets();
  }, [queryClient]);

  const filteredMarkets = (markets as any)?.markets?.filter((market: Market) => {
    // Category filter
    if (filters.categories.length > 0 && !filters.categories.includes(market.category || '')) {
      return false;
    }

    // Value assessment filter
    if (filters.valueAssessment !== 'all' && market.valueAssessment !== filters.valueAssessment) {
      return false;
    }

    // Score range filter
    const score = parseFloat(market.predictWiseScore || '0');
    if (score < filters.scoreRange[0] || score > filters.scoreRange[1]) {
      return false;
    }

    return true;
  }) || [];

  const sortedMarkets = [...filteredMarkets].sort((a, b) => {
    switch (sortBy) {
      case 'score':
        return parseFloat(b.predictWiseScore || '0') - parseFloat(a.predictWiseScore || '0');
      case 'volume':
        return parseFloat(b.volume || '0') - parseFloat(a.volume || '0');
      case 'change':
        return parseFloat(b.priceChange || '0') - parseFloat(a.priceChange || '0');
      default:
        return 0;
    }
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleRequestScore = (marketId: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please log in to view MarketEdge scores.",
        variant: "destructive",
      });
      return;
    }

    useScoreMutation.mutate({ userId: user.id, marketId });
    setScoresUsedInSession(prev => [...prev, marketId]);
  };

  const canShowScore = (marketId: string) => {
    return isPro || scoresUsedInSession.includes(marketId);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header onSearch={handleSearch} />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to MarketEdge</h1>
          <p className="text-xl text-gray-600 mb-8">
            Analyze prediction markets and discover value opportunities with our advanced scoring system.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="/register">
              <Button size="lg" data-testid="button-get-started">Get Started</Button>
            </Link>
            <Link href="/login">
              <Button variant="outline" size="lg">Learn More</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header onSearch={handleSearch} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <StatsOverview />
        <SubscriptionPrompt />
        
        <div className="flex flex-col lg:flex-row gap-8">
          <MarketFilters onFiltersChange={setFilters} />
          
          <div className="flex-1">
            <Card>
              <CardContent className="p-6">
                {/* Header */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold text-gray-900">Active Markets</h2>
                    <div className="flex items-center space-x-3">
                      <Select value={sortBy} onValueChange={setSortBy}>
                        <SelectTrigger className="w-48" data-testid="select-sort">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="score">Sort by MarketEdge Score</SelectItem>
                          <SelectItem value="volume">Sort by Volume</SelectItem>
                          <SelectItem value="change">Sort by Price Change</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                
                {/* Markets List */}
                {marketsLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="animate-spin mr-2" size={24} />
                    <span>Loading markets...</span>
                  </div>
                ) : sortedMarkets.length > 0 ? (
                  <div className="space-y-4">
                    {sortedMarkets.map((market) => (
                      <MarketCard
                        key={market.id}
                        market={market}
                        onClick={() => setSelectedMarket(market)}
                        onRequestScore={() => handleRequestScore(market.id)}
                        showScore={canShowScore(market.id)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-500">No markets found matching your criteria.</p>
                  </div>
                )}
                
                {/* Load More */}
                {sortedMarkets.length > 0 && sortedMarkets.length >= 50 && (
                  <div className="text-center mt-8 pt-6 border-t border-gray-200">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        toast({
                          title: "Feature Coming Soon",
                          description: "Load more functionality will be available in the next update.",
                        });
                      }}
                      data-testid="button-load-more"
                    >
                      Load More Markets
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Market Detail Modal */}
      <MarketModal
        market={selectedMarket}
        isOpen={!!selectedMarket}
        onClose={() => setSelectedMarket(null)}
      />

      {/* Mobile Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-40">
        <div className="grid grid-cols-4 gap-1">
          <button 
            className="flex flex-col items-center p-3 text-primary" 
            data-testid="button-mobile-markets"
            onClick={() => setLocation('/')}
          >
            <BarChart3 size={20} className="mb-1" />
            <span className="text-xs font-medium">Markets</span>
          </button>
          <button 
            className="flex flex-col items-center p-3 text-gray-400 hover:text-primary transition-colors" 
            data-testid="button-mobile-analytics"
            onClick={() => setLocation('/analytics')}
          >
            <BarChart3 size={20} className="mb-1" />
            <span className="text-xs">Analytics</span>
          </button>
          <button 
            className="flex flex-col items-center p-3 text-gray-400 hover:text-primary transition-colors" 
            data-testid="button-mobile-portfolio"
            onClick={() => setLocation('/portfolio')}
          >
            <Wallet size={20} className="mb-1" />
            <span className="text-xs">Portfolio</span>
          </button>
          <button 
            className="flex flex-col items-center p-3 text-gray-400 hover:text-primary transition-colors" 
            data-testid="button-mobile-profile"
            onClick={() => {
              if (user) {
                setLocation('/portfolio');
              } else {
                setLocation('/login');
              }
            }}
          >
            <User size={20} className="mb-1" />
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}
