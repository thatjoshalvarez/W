import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Header } from '@/components/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { Crown, Check, X, Loader2 } from 'lucide-react';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : null;

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { updateUser } = useAuth();
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      updateUser({ subscriptionTier: 'pro' });
      toast({
        title: "Welcome to Pro!",
        description: "You now have unlimited access to MarketEdge scores and analytics.",
      });
      setLocation('/');
    }
    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isLoading} 
        className="w-full"
        data-testid="button-subscribe"
      >
        {isLoading ? (
          <>
            <Loader2 className="animate-spin mr-2" size={16} />
            Processing...
          </>
        ) : (
          'Subscribe to Pro - $1.99/month'
        )}
      </Button>
    </form>
  );
};

export default function Subscribe() {
  const { user, isPro } = useAuth();
  const [, setLocation] = useLocation();
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLocation('/');
      return;
    }

    if (isPro) {
      setLocation('/');
      return;
    }

    // Create subscription
    apiRequest("POST", "/api/create-subscription", { userId: user.id })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Subscription creation error:', error);
        setIsLoading(false);
      });
  }, [user, isPro, setLocation]);

  const features = {
    free: [
      "View all prediction markets",
      "Basic market information",
      "10 MarketEdge Scores per day",
      "Basic price charts",
      "Community support"
    ],
    pro: [
      "Everything in Free",
      "Unlimited MarketEdge Scores",
      "Advanced market analytics",
      "Historical price data",
      "Real-time 24/7 market updates",
      "Portfolio tracking",
      "Priority support",
      "Export capabilities"
    ]
  };

  if (!stripePromise) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Payment System Unavailable</h1>
          <p className="text-gray-600">
            Stripe is not configured. Please contact support to set up your Pro subscription.
          </p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <Loader2 className="animate-spin mx-auto mb-4" size={48} />
          <p className="text-gray-600">Setting up your subscription...</p>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Subscription Error</h1>
          <p className="text-gray-600">
            Unable to create subscription. Please try again or contact support.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Upgrade to MarketEdge Pro
          </h1>
          <p className="text-xl text-gray-600">
            Unlock unlimited market analysis and advanced features for just $1.99/month
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Free Plan */}
          <Card className="border-2">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold">Free</CardTitle>
              <div className="text-4xl font-bold text-gray-900">$0</div>
              <p className="text-gray-600">Perfect for getting started</p>
              <Badge variant="secondary">Current Plan</Badge>
              <p className="text-xs text-gray-500 mt-2">24/7 updated markets included</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {features.free.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="text-success mr-3 flex-shrink-0" size={16} />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Pro Plan */}
          <Card className="border-2 border-primary shadow-lg relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-gradient-to-r from-primary to-blue-600 text-white px-4 py-1">
                <Crown className="mr-1" size={12} />
                RECOMMENDED
              </Badge>
            </div>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold">Pro</CardTitle>
              <div className="text-4xl font-bold text-primary">$1.99</div>
              <p className="text-gray-600">per month</p>
              <p className="text-xs text-gray-500 mt-2">24/7 updated markets + unlimited scores</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                {features.pro.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="text-success mr-3 flex-shrink-0" size={16} />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Payment Form */}
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Complete Your Subscription</CardTitle>
            </CardHeader>
            <CardContent>
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <SubscribeForm />
              </Elements>
              
              <div className="mt-6 text-center text-sm text-gray-500">
                <p>Cancel anytime. No hidden fees.</p>
                <p className="mt-2">
                  By subscribing, you agree to our Terms of Service and Privacy Policy.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div>
              <h3 className="font-semibold mb-2">Can I cancel anytime?</h3>
              <p className="text-gray-600 text-sm">
                Yes, you can cancel your subscription at any time. You'll continue to have Pro access until the end of your billing period.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">What payment methods do you accept?</h3>
              <p className="text-gray-600 text-sm">
                We accept all major credit cards and debit cards through our secure payment processor Stripe.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">How accurate are PredictWise Scores?</h3>
              <p className="text-gray-600 text-sm">
                Our scores are based on proprietary algorithms analyzing market data, historical patterns, and various risk factors.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Do you offer refunds?</h3>
              <p className="text-gray-600 text-sm">
                We offer a 7-day satisfaction guarantee. If you're not happy with Pro features, contact us for a full refund.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
