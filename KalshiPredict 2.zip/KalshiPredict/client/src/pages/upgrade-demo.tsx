import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/header';
import { useLocation } from 'wouter';
import { Crown, Check } from 'lucide-react';

export default function UpgradeDemo() {
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleUpgrade = () => {
    if (user) {
      updateUser({ subscriptionTier: 'pro' });
      toast({
        title: "Welcome to Pro!",
        description: "You now have unlimited access to MarketEdge scores and analytics. Demo mode - no payment required.",
      });
      setLocation('/');
    }
  };

  const features = {
    free: [
      "View all prediction markets",
      "Basic market information", 
      "10 MarketEdge Scores per day",
      "Basic price charts",
      "Community support"
    ],
    pro: [
      "Everything in Free",
      "Unlimited MarketEdge Scores",
      "Advanced market analytics", 
      "Historical price data",
      "Real-time 24/7 market updates",
      "Portfolio tracking",
      "Priority support",
      "Export capabilities"
    ]
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Upgrade to MarketEdge Pro
          </h1>
          <p className="text-xl text-gray-600">
            Demo Mode: Upgrade instantly for $1.99/month (no payment required for demo)
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Free Plan */}
          <Card className="border-2">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold">Free</CardTitle>
              <div className="text-4xl font-bold text-gray-900">$0</div>
              <p className="text-gray-600">Perfect for getting started</p>
              <Badge variant="secondary">Current Plan</Badge>
              <p className="text-xs text-gray-500 mt-2">24/7 updated markets included</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {features.free.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="text-success mr-3 flex-shrink-0" size={16} />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Pro Plan */}
          <Card className="border-2 border-primary shadow-lg relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-gradient-to-r from-primary to-blue-600 text-white px-4 py-1">
                <Crown className="mr-1" size={12} />
                RECOMMENDED
              </Badge>
            </div>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold">Pro</CardTitle>
              <div className="text-4xl font-bold text-primary">$1.99</div>
              <p className="text-gray-600">per month</p>
              <p className="text-xs text-gray-500 mt-2">24/7 updated markets + unlimited scores</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                {features.pro.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="text-success mr-3 flex-shrink-0" size={16} />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Demo Upgrade Button */}
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Demo Upgrade</CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={handleUpgrade}
                className="w-full"
                data-testid="button-demo-upgrade"
              >
                <Crown className="mr-2" size={16} />
                Upgrade to Pro (Demo - Free)
              </Button>
              
              <div className="mt-6 text-center text-sm text-gray-500">
                <p>Demo mode: Instant upgrade without payment</p>
                <p className="mt-2">
                  Real version: Cancel anytime. No hidden fees.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}