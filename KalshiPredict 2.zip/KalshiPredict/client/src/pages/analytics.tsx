import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Header } from '@/components/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart3, TrendingUp, Target, Clock, Users, DollarSign } from 'lucide-react';

export default function Analytics() {
  const { user, isPro } = useAuth();

  const metrics = [
    {
      title: 'Market Insights',
      value: '127',
      subtitle: 'Active markets tracked',
      icon: BarChart3,
      trend: '+12%',
      trendUp: true
    },
    {
      title: 'Accuracy Score',
      value: '73.2%',
      subtitle: 'MarketEdge prediction accuracy',
      icon: Target,
      trend: '+5.1%',
      trendUp: true
    },
    {
      title: 'Average Volume',
      value: '$2.4M',
      subtitle: 'Daily trading volume',
      icon: DollarSign,
      trend: '+18%',
      trendUp: true
    },
    {
      title: 'Market Participants',
      value: '8,432',
      subtitle: 'Active traders',
      icon: Users,
      trend: '+23%',
      trendUp: true
    }
  ];

  const topMarkets = [
    {
      title: 'Will Bitcoin reach $100,000 by end of 2024?',
      category: 'Crypto',
      score: 8.2,
      volume: '$5.2M',
      trend: 'good_value'
    },
    {
      title: 'Will the Fed cut rates by 0.25% in December 2024?',
      category: 'Economics',
      score: 6.8,
      volume: '$2.4M',
      trend: 'overpriced'
    },
    {
      title: 'Will Taylor Swift attend the Super Bowl?',
      category: 'Sports',
      score: 7.1,
      volume: '$890K',
      trend: 'fair_value'
    }
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Advanced Analytics</h1>
          <p className="text-gray-600 mb-8">Sign in to access detailed market analytics and insights</p>
          <Button data-testid="button-sign-in">Sign In</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
          <p className="text-gray-600">Deep insights into prediction market trends and opportunities</p>
        </div>

        {!isPro && (
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-blue-50 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Unlock Advanced Analytics</h3>
                  <p className="text-gray-600 text-sm">Get detailed market analysis, historical data, and predictive insights with Pro.</p>
                </div>
                <Button data-testid="button-upgrade-analytics">
                  Upgrade to Pro
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <metric.icon className="text-primary" size={24} />
                  <span className={`text-sm font-medium ${metric.trendUp ? 'text-green-600' : 'text-red-600'}`}>
                    {metric.trend}
                  </span>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                  <p className="text-sm text-gray-600">{metric.subtitle}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Top Markets */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2" size={20} />
              Trending Markets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topMarkets.map((market, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 mb-1">{market.title}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <Badge variant="secondary">{market.category}</Badge>
                      <span>Volume: {market.volume}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold">
                      {market.score}/10
                    </p>
                    <Badge variant={
                      market.trend === 'good_value' ? 'default' : 
                      market.trend === 'fair_value' ? 'secondary' : 
                      'destructive'
                    }>
                      {market.trend === 'good_value' ? 'Good Value' :
                       market.trend === 'fair_value' ? 'Fair Value' :
                       'Overpriced'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Coming Soon Features */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="opacity-60">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="mr-2" size={20} />
                Historical Analysis
                <Badge variant="outline" className="ml-2">Coming Soon</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Analyze historical price movements and identify patterns in prediction markets.
              </p>
            </CardContent>
          </Card>

          <Card className="opacity-60">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="mr-2" size={20} />
                Predictive Models
                <Badge variant="outline" className="ml-2">Coming Soon</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Advanced AI-powered predictions and market sentiment analysis.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}