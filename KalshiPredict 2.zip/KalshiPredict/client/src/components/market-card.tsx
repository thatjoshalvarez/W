import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowUp, ArrowDown, Minus, Clock, BarChart3, Users, Star, Lock } from 'lucide-react';
import type { Market } from '@shared/schema';
import { useAuth } from '@/hooks/use-auth';
import { cn } from '@/lib/utils';

interface MarketCardProps {
  market: Market;
  onClick: () => void;
  onRequestScore: () => void;
  showScore?: boolean;
}

export function MarketCard({ market, onClick, onRequestScore, showScore = true }: MarketCardProps) {
  const { isPro } = useAuth();

  const getValueColor = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return 'text-success';
      case 'fair_value': return 'text-warning';
      case 'overpriced': return 'text-error';
      default: return 'text-gray-500';
    }
  };

  const getValueBgColor = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return 'bg-success/10';
      case 'fair_value': return 'bg-warning/10';
      case 'overpriced': return 'bg-error/10';
      default: return 'bg-gray-100';
    }
  };

  const getValueIcon = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return <ArrowUp className="text-success" size={16} />;
      case 'fair_value': return <Minus className="text-warning" size={16} />;
      case 'overpriced': return <ArrowDown className="text-error" size={16} />;
      default: return <Minus className="text-gray-400" size={16} />;
    }
  };

  const getValueLabel = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return 'Good Value';
      case 'fair_value': return 'Fair Value';
      case 'overpriced': return 'Overpriced';
      default: return 'Unknown';
    }
  };

  const getCategoryColor = (category: string | null) => {
    switch (category?.toLowerCase()) {
      case 'politics': return 'bg-blue-100 text-blue-800';
      case 'economics': return 'bg-blue-100 text-blue-800';
      case 'sports': return 'bg-green-100 text-green-800';
      case 'tech': return 'bg-purple-100 text-purple-800';
      case 'crypto': return 'bg-purple-100 text-purple-800';
      case 'entertainment': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatPrice = (price: string | null) => {
    if (!price) return '--';
    return `${Math.round(parseFloat(price))}¢`;
  };

  const formatVolume = (volume: string | null) => {
    if (!volume) return '--';
    const val = parseFloat(volume);
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val}`;
  };

  const formatPriceChange = (change: string | null) => {
    if (!change) return null;
    const val = parseFloat(change);
    const isPositive = val >= 0;
    return (
      <span className={isPositive ? 'text-success' : 'text-error'}>
        {isPositive ? <ArrowUp size={12} className="inline mr-1" /> : <ArrowDown size={12} className="inline mr-1" />}
        {Math.abs(val)}%
      </span>
    );
  };

  return (
    <Card className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={onClick}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-3 mb-2">
              <h3 className="text-lg font-medium text-gray-900 truncate" data-testid={`text-market-title-${market.id}`}>
                {market.title}
              </h3>
              <Badge className={getCategoryColor(market.category)} data-testid={`badge-category-${market.id}`}>
                {market.category}
              </Badge>
            </div>
            <p className="text-sm text-gray-600 mb-3" data-testid={`text-market-description-${market.id}`}>
              {market.description}
            </p>
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <span className="flex items-center">
                <Clock size={12} className="mr-1" />
                Ends {market.endDate ? new Date(market.endDate).toLocaleDateString() : 'TBD'}
              </span>
              <span className="flex items-center">
                <BarChart3 size={12} className="mr-1" />
                Volume: {formatVolume(market.volume)}
              </span>
              <span className="flex items-center">
                <Users size={12} className="mr-1" />
                {market.traders || 0} traders
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-6 ml-6">
            {/* Current Price */}
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Current Price</div>
              <div className="text-xl font-bold text-gray-900" data-testid={`text-current-price-${market.id}`}>
                {formatPrice(market.currentPrice)}
              </div>
              <div className="text-sm">
                {formatPriceChange(market.priceChange) || <span className="text-gray-400">--</span>}
              </div>
            </div>
            
            {/* Fair Value */}
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Fair Value</div>
              <div className="text-xl font-bold text-primary" data-testid={`text-fair-value-${market.id}`}>
                {formatPrice(market.fairValue)}
              </div>
              <div className={cn("text-xs font-medium", getValueColor(market.valueAssessment))}>
                {getValueLabel(market.valueAssessment)}
              </div>
            </div>
            
            {/* PredictWise Score */}
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1 flex items-center justify-center">
                <span>Score</span>
                {!showScore && !isPro && (
                  <div className="relative group ml-1">
                    <Lock size={12} className="text-gray-400 cursor-help" />
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      Upgrade to Pro for unlimited MarketEdge scores
                    </div>
                  </div>
                )}
              </div>
              {showScore || isPro ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="text-2xl font-bold text-warning" data-testid={`text-score-${market.id}`}>
                    {market.predictWiseScore || '--'}
                  </div>
                  <div className="w-8 h-8 bg-warning rounded-full flex items-center justify-center">
                    <Star className="text-white" size={12} />
                  </div>
                </div>
              ) : (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onRequestScore();
                  }}
                  className="text-xl font-bold text-gray-300 hover:text-primary transition-colors"
                  data-testid={`button-request-score-${market.id}`}
                >
                  --
                </button>
              )}
            </div>
            
            {/* Value Indicator */}
            <div className={cn("w-12 h-12 rounded-full flex items-center justify-center", getValueBgColor(market.valueAssessment))}>
              {getValueIcon(market.valueAssessment)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
