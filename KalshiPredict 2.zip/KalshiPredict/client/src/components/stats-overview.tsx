import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { ChartBar, ThumbsUp, Star, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

export function StatsOverview() {
  const { user } = useAuth();
  
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const dailyScoresUsed = user?.dailyScoresUsed || 0;
  const maxDailyScores = user?.subscriptionTier === 'pro' ? '∞' : '10';

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Markets</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-active-markets">
                {(stats as any)?.activeMarkets || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <ChartBar className="text-primary" size={20} />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Good Value Opportunities</p>
              <p className="text-2xl font-bold text-success" data-testid="text-good-value-count">
                {(stats as any)?.goodValueCount || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
              <ThumbsUp className="text-success" size={20} />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg. MarketEdge Score</p>
              <p className="text-2xl font-bold text-warning" data-testid="text-avg-score">
                {(stats as any)?.avgScore || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
              <Star className="text-warning" size={20} />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Daily Scores Used</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-daily-scores">
                <span>{dailyScoresUsed}</span>
                <span className="text-sm text-gray-500">/{maxDailyScores}</span>
              </p>
            </div>
            <div className="w-12 h-12 bg-error/10 rounded-lg flex items-center justify-center">
              <AlertTriangle className="text-error" size={20} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
