import { useState } from 'react';
import { Link } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Search, ChartLine, User, ChevronDown } from 'lucide-react';

interface HeaderProps {
  onSearch?: (query: string) => void;
}

export function Header({ onSearch }: HeaderProps) {
  const { user, logout, isPro } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link href="/">
              <div className="flex items-center space-x-3 cursor-pointer" data-testid="link-home">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <ChartLine className="text-white" size={16} />
                </div>
                <h1 className="text-xl font-bold text-gray-900">MarketEdge</h1>
              </div>
            </Link>
            
            <nav className="hidden md:flex space-x-6">
              <Link href="/">
                <a className="text-primary font-medium border-b-2 border-primary pb-4" data-testid="link-markets">
                  Markets
                </a>
              </Link>
              <Link href="/analytics">
                <a className="text-gray-600 hover:text-gray-900 pb-4" data-testid="link-analytics">
                  Analytics
                </a>
              </Link>
              <Link href="/portfolio">
                <a className="text-gray-600 hover:text-gray-900 pb-4" data-testid="link-portfolio">
                  Portfolio
                </a>
              </Link>
              <Link href="/education">
                <a className="text-gray-600 hover:text-gray-900 pb-4" data-testid="link-education">
                  Education
                </a>
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Search */}
            <form onSubmit={handleSearchSubmit} className="relative hidden sm:block">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="text-gray-400" size={16} />
              </div>
              <Input
                type="text"
                placeholder="Search markets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-64"
                data-testid="input-search"
              />
            </form>
            
            {user && (
              <>
                {/* Subscription Status */}
                <Badge 
                  variant={isPro ? "default" : "secondary"}
                  className={isPro ? "bg-gradient-to-r from-primary to-blue-600 text-white" : ""}
                  data-testid="badge-subscription"
                >
                  {isPro ? "PRO" : "FREE"}
                </Badge>
                
                {/* User Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-2" data-testid="button-user-menu">
                      <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                        <User size={16} />
                      </div>
                      <ChevronDown size={12} />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem data-testid="text-username">
                      {user.username}
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/upgrade">
                        <span data-testid="link-upgrade">Upgrade to Pro</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={logout} data-testid="button-logout">
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
            
            {!user && (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="outline" data-testid="button-login">Login</Button>
                </Link>
                <Link href="/register">
                  <Button data-testid="button-register">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
