import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface MarketFiltersProps {
  onFiltersChange: (filters: {
    categories: string[];
    valueAssessment: string;
    scoreRange: number[];
  }) => void;
}

const categories = [
  { name: 'Politics', count: 342 },
  { name: 'Economics', count: 189 },
  { name: 'Sports', count: 156 },
  { name: 'Tech', count: 98 },
  { name: 'Crypto', count: 76 },
  { name: 'Entertainment', count: 54 },
];

export function MarketFilters({ onFiltersChange }: MarketFiltersProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [valueAssessment, setValueAssessment] = useState('all');
  const [scoreRange, setScoreRange] = useState([0, 10]);

  const handleCategoryChange = (category: string, checked: boolean) => {
    const newCategories = checked
      ? [...selectedCategories, category]
      : selectedCategories.filter(c => c !== category);
    
    setSelectedCategories(newCategories);
    onFiltersChange({
      categories: newCategories,
      valueAssessment,
      scoreRange,
    });
  };

  const handleValueAssessmentChange = (value: string) => {
    setValueAssessment(value);
    onFiltersChange({
      categories: selectedCategories,
      valueAssessment: value,
      scoreRange,
    });
  };

  const handleScoreRangeChange = (value: number[]) => {
    setScoreRange(value);
    onFiltersChange({
      categories: selectedCategories,
      valueAssessment,
      scoreRange: value,
    });
  };

  return (
    <Card className="w-64 flex-shrink-0">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filters</h3>
        
        {/* Categories */}
        <div className="mb-6">
          <Label className="text-sm font-medium text-gray-700 mb-3 block">Categories</Label>
          <div className="space-y-2">
            {categories.map(category => (
              <div key={category.name} className="flex items-center space-x-2">
                <Checkbox
                  id={category.name}
                  checked={selectedCategories.includes(category.name)}
                  onCheckedChange={(checked) => 
                    handleCategoryChange(category.name, checked as boolean)
                  }
                  data-testid={`checkbox-category-${category.name.toLowerCase()}`}
                />
                <Label 
                  htmlFor={category.name} 
                  className="text-sm text-gray-700 flex-1 cursor-pointer"
                >
                  {category.name}
                </Label>
                <span className="text-xs text-gray-500" data-testid={`text-count-${category.name.toLowerCase()}`}>
                  {category.count}
                </span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Value Assessment */}
        <div className="mb-6">
          <Label className="text-sm font-medium text-gray-700 mb-3 block">Value Assessment</Label>
          <RadioGroup value={valueAssessment} onValueChange={handleValueAssessmentChange}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="all" id="all" />
              <Label htmlFor="all" className="text-sm text-gray-700">All Markets</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="good_value" id="good_value" />
              <Label htmlFor="good_value" className="text-sm text-gray-700">Good Value</Label>
              <div className="w-3 h-3 bg-success rounded-full" />
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="fair_value" id="fair_value" />
              <Label htmlFor="fair_value" className="text-sm text-gray-700">Fair Value</Label>
              <div className="w-3 h-3 bg-warning rounded-full" />
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="overpriced" id="overpriced" />
              <Label htmlFor="overpriced" className="text-sm text-gray-700">Overpriced</Label>
              <div className="w-3 h-3 bg-error rounded-full" />
            </div>
          </RadioGroup>
        </div>
        
        {/* Score Range */}
        <div>
          <Label className="text-sm font-medium text-gray-700 mb-3 block">
            MarketEdge Score: {scoreRange[0]} - {scoreRange[1]}
          </Label>
          <div className="space-y-3">
            <Slider
              value={scoreRange}
              onValueChange={handleScoreRangeChange}
              max={10}
              min={0}
              step={0.1}
              className="w-full"
              data-testid="slider-score-range"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0</span>
              <span>5</span>
              <span>10</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
