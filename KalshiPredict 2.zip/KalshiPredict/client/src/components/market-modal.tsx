import { useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ExternalLink, Check, AlertCircle, Lightbulb } from 'lucide-react';
import type { Market } from '@shared/schema';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface MarketModalProps {
  market: Market | null;
  isOpen: boolean;
  onClose: () => void;
}

export function MarketModal({ market, isOpen, onClose }: MarketModalProps) {

  // Generate chart data
  const getChartData = () => {
    if (!market) return null;
    
    const labels = ['Nov 1', 'Nov 8', 'Nov 15', 'Nov 22', 'Nov 29', 'Dec 6', 'Dec 13'];
    const currentPrice = parseFloat(market.currentPrice || '50');
    const fairValue = parseFloat(market.fairValue || '50');
    
    // Generate realistic price movement
    const priceData = labels.map((_, i) => {
      const base = currentPrice - (labels.length - 1 - i) * 3;
      const variance = Math.random() * 10 - 5;
      return Math.max(0, Math.min(100, base + variance));
    });
    
    return {
      labels,
      datasets: [{
        label: 'Market Price',
        data: priceData,
        borderColor: 'hsl(203.8863, 88.2845%, 53.1373%)',
        backgroundColor: 'hsla(203.8863, 88.2845%, 53.1373%, 0.1)',
        fill: true,
        tension: 0.4
      }, {
        label: 'Fair Value',
        data: labels.map(() => fairValue),
        borderColor: 'hsl(147.1429, 78.5047%, 41.9608%)',
        backgroundColor: 'transparent',
        borderDash: [5, 5],
        fill: false
      }]
    };
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      }
    },
    scales: {
      y: {
        beginAtZero: false,
        min: 0,
        max: 100,
        ticks: {
          callback: function(value: any) {
            return value + '¢';
          }
        }
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const
    }
  };

  if (!market) return null;

  const formatPrice = (price: string | null) => {
    if (!price) return '--';
    return `${Math.round(parseFloat(price))}¢`;
  };

  const formatVolume = (volume: string | null) => {
    if (!volume) return '--';
    const val = parseFloat(volume);
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val}`;
  };

  const getCategoryColor = (category: string | null) => {
    switch (category?.toLowerCase()) {
      case 'politics': return 'bg-blue-100 text-blue-800';
      case 'economics': return 'bg-blue-100 text-blue-800';
      case 'sports': return 'bg-green-100 text-green-800';
      case 'tech': return 'bg-purple-100 text-purple-800';
      case 'crypto': return 'bg-purple-100 text-purple-800';
      case 'entertainment': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getValueAssessmentColor = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return 'text-success';
      case 'fair_value': return 'text-warning';
      case 'overpriced': return 'text-error';
      default: return 'text-gray-500';
    }
  };

  const getValueAssessmentLabel = (assessment: string | null) => {
    switch (assessment) {
      case 'good_value': return 'Good Value';
      case 'fair_value': return 'Fair Value';
      case 'overpriced': return 'Overpriced';
      default: return 'Unknown';
    }
  };

  const handleTradeOnKalshi = () => {
    // Open Kalshi market in new tab
    const kalshiUrl = `https://kalshi.com/events/${market.ticker}`;
    window.open(kalshiUrl, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full max-h-[90vh] overflow-hidden" aria-describedby="market-modal-description">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <DialogTitle className="text-2xl font-bold text-gray-900">
                {market.title}
              </DialogTitle>
              <Badge className={getCategoryColor(market.category)}>
                {market.category}
              </Badge>
            </div>
          </div>
          <p id="market-modal-description" className="text-gray-600 mt-1">
            {market.description}
          </p>
        </DialogHeader>
        
        <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-6">
            {/* Chart Area */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Price History</h3>
                  <div className="h-64">
                    {getChartData() && (
                      <Line data={getChartData()!} options={chartOptions} data-testid="chart-price-history" />
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Market Analysis</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Key Factors</h4>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li className="flex items-start space-x-2">
                          <Check className="text-success mt-1 flex-shrink-0" size={12} />
                          <span>Strong market fundamentals suggest continued movement</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <Check className="text-success mt-1 flex-shrink-0" size={12} />
                          <span>High trading volume indicates strong market interest</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <AlertCircle className="text-warning mt-1 flex-shrink-0" size={12} />
                          <span>External factors could impact final outcome</span>
                        </li>
                      </ul>
                    </div>
                    
                    <Card className="bg-primary/5 border-primary/20">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                            <Lightbulb className="text-white" size={16} />
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900 mb-1">MarketEdge Analysis</h4>
                            <p className="text-sm text-gray-600">
                              Current market price of {formatPrice(market.currentPrice)} compared to our fair value estimate of {formatPrice(market.fairValue)}. 
                              Our analysis suggests this market is currently {getValueAssessmentLabel(market.valueAssessment).toLowerCase()}.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Market Stats */}
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Market Stats</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Current Price</span>
                      <span className="font-semibold" data-testid="text-modal-current-price">
                        {formatPrice(market.currentPrice)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Fair Value</span>
                      <span className="font-semibold text-primary" data-testid="text-modal-fair-value">
                        {formatPrice(market.fairValue)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">24h Change</span>
                      <span className="font-semibold text-success" data-testid="text-modal-price-change">
                        +{market.priceChange || 0}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Volume</span>
                      <span className="font-semibold" data-testid="text-modal-volume">
                        {formatVolume(market.volume)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Open Interest</span>
                      <span className="font-semibold" data-testid="text-modal-open-interest">
                        {formatVolume(market.openInterest)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Traders</span>
                      <span className="font-semibold" data-testid="text-modal-traders">
                        {market.traders || 0}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">MarketEdge Score</h3>
                  <div className="text-center mb-4">
                    <div className="text-4xl font-bold text-warning mb-2" data-testid="text-modal-score">
                      {market.predictWiseScore || '--'}
                    </div>
                    <div className="text-sm text-gray-600">Out of 10</div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Value Assessment</span>
                      <span className={`font-medium ${getValueAssessmentColor(market.valueAssessment)}`}>
                        {getValueAssessmentLabel(market.valueAssessment)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Volatility Risk</span>
                      <span className="text-warning font-medium">Medium</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Liquidity</span>
                      <span className="text-success font-medium">High</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Time to Resolution</span>
                      <span className="text-gray-700 font-medium">
                        {market.endDate ? 
                          Math.ceil((new Date(market.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) + ' days'
                          : 'TBD'
                        }
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Button 
                onClick={handleTradeOnKalshi}
                className="w-full"
                data-testid="button-trade-kalshi"
              >
                <ExternalLink className="mr-2" size={16} />
                Trade on Kalshi
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
