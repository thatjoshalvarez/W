import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Crown } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

export function SubscriptionPrompt() {
  const { user, isPro } = useAuth();

  // Don't show prompt if user is already pro or not logged in
  if (!user || isPro) return null;

  return (
    <div className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-6 mb-8 text-white">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
            <Crown className="text-white" size={24} />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Unlock Unlimited Analysis</h3>
            <p className="text-blue-100">Get unlimited MarketEdge Scores and advanced analytics for just $1.99/month</p>
          </div>
        </div>
        <Link href="/upgrade">
          <Button 
            className="bg-white text-primary px-6 py-2 font-medium hover:bg-gray-50 transition-colors"
            data-testid="button-upgrade"
          >
            Upgrade Now
          </Button>
        </Link>
      </div>
    </div>
  );
}
