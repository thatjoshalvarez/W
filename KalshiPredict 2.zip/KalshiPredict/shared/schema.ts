import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  subscriptionTier: text("subscription_tier").default("free"), // "free" or "pro"
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  dailyScoresUsed: integer("daily_scores_used").default(0),
  lastScoreReset: timestamp("last_score_reset").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const markets = pgTable("markets", {
  id: varchar("id").primaryKey(),
  ticker: text("ticker").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"),
  currentPrice: decimal("current_price", { precision: 10, scale: 2 }),
  fairValue: decimal("fair_value", { precision: 10, scale: 2 }),
  predictWiseScore: decimal("predict_wise_score", { precision: 3, scale: 1 }),
  volume: decimal("volume", { precision: 15, scale: 2 }),
  traders: integer("traders"),
  endDate: timestamp("end_date"),
  priceChange: decimal("price_change", { precision: 5, scale: 2 }),
  openInterest: decimal("open_interest", { precision: 15, scale: 2 }),
  valueAssessment: text("value_assessment"), // "good_value", "fair_value", "overpriced"
  isActive: boolean("is_active").default(true),
  lastUpdated: timestamp("last_updated").defaultNow(),
  priceHistory: jsonb("price_history"),
});

export const userScoreUsage = pgTable("user_score_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  marketId: varchar("market_id").notNull().references(() => markets.id),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
  password: true,
});

export const insertMarketSchema = createInsertSchema(markets).omit({
  id: true,
  lastUpdated: true,
});

export const insertScoreUsageSchema = createInsertSchema(userScoreUsage).omit({
  id: true,
  timestamp: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMarket = z.infer<typeof insertMarketSchema>;
export type Market = typeof markets.$inferSelect;
export type InsertScoreUsage = z.infer<typeof insertScoreUsageSchema>;
export type ScoreUsage = typeof userScoreUsage.$inferSelect;
