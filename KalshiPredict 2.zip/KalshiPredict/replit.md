# MarketEdge - Prediction Market Analysis App

*Formerly "PredictWise" - renamed to avoid trademark conflicts*

## Project Overview
MarketEdge is a React-based prediction market analysis app that analyzes Kalshi market prices to identify good value betting opportunities. The app highlights favorable trading opportunities with price analysis and market insights.

## Features
- Real-time market data from Kalshi API
- Price opportunity analysis and indicators
- Market trend visualization
- Portfolio tracking and management
- Value betting recommendations

## Tech Stack
- Frontend: React + TypeScript with Vite
- Backend: Express.js
- Styling: Tailwind CSS + shadcn/ui
- State Management: TanStack Query
- Routing: Wouter
- Forms: React Hook Form + Zod
- Storage: In-memory (MemStorage)

## Project Architecture
- `/client` - React frontend application
- `/server` - Express.js backend API
- `/shared` - Shared types and schemas
- Database schema defined in `shared/schema.ts`
- API routes in `server/routes.ts`
- Storage interface in `server/storage.ts`

## User Preferences
- App name: MarketEdge (to avoid trademark issues with Kalshi)
- Focus: Identify good price opportunities for predictions
- Simple, everyday language for user interactions
- Renamed from "PredictWise" to "MarketEdge" throughout the application

## Recent Changes
- ✓ Complete application architecture implemented with React frontend and Node.js backend
- ✓ Full subscription system integrated with Stripe ($1.99/month Pro tier + free tier)
- ✓ All core components built: market cards, filters, modal details, stats overview, and subscription prompts
- ✓ Fixed text overlap issues in markets section with proper spacing and responsive design
- ✓ Integrated Kalshi API for real-time market data and price analysis features
- ✓ Brand name updated from "PredictWise" to "MarketEdge" throughout the application
- ✓ All LSP errors resolved and application ready for deployment
- ✓ Stripe payment integration configured with API keys
- ✓ Fixed Load More button with proper functionality and user feedback
- ✓ Added Portfolio page with Kalshi portfolio linking and position tracking
- ✓ Added Analytics dashboard with market insights and metrics
- ✓ Made bottom navigation tabs fully functional with proper routing

## Development Status
- ✓ Full stack application completed and running
- ✓ Stripe payment system integrated and configured
- ✓ Real-time Kalshi market data integration
- ✓ Two-tier subscription model (Free + Pro at $1.99/month) implemented
- ✓ Advanced market analysis with MarketEdge scoring system
- ✓ Ready for user testing and deployment