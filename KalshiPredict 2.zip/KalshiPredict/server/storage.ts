import { type User, type InsertUser, type Market, type InsertMarket, type ScoreUsage, type InsertScoreUsage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User>;
  updateUserSubscriptionTier(userId: string, tier: "free" | "pro"): Promise<User>;
  incrementUserScoreUsage(userId: string): Promise<User>;
  resetUserDailyScores(userId: string): Promise<User>;
  
  // Market methods
  getAllMarkets(): Promise<Market[]>;
  getMarket(id: string): Promise<Market | undefined>;
  getMarketByTicker(ticker: string): Promise<Market | undefined>;
  createMarket(market: InsertMarket): Promise<Market>;
  updateMarket(id: string, updates: Partial<Market>): Promise<Market>;
  getMarketsByCategory(category: string): Promise<Market[]>;
  searchMarkets(query: string): Promise<Market[]>;
  
  // Score usage methods
  recordScoreUsage(usage: InsertScoreUsage): Promise<ScoreUsage>;
  getUserScoreUsageToday(userId: string): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private markets: Map<string, Market>;
  private scoreUsage: Map<string, ScoreUsage>;

  constructor() {
    this.users = new Map();
    this.markets = new Map();
    this.scoreUsage = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      subscriptionTier: "free",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      dailyScoresUsed: 0,
      lastScoreReset: new Date(),
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = {
      ...user,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscriptionId,
      subscriptionTier: "pro" as const,
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserSubscriptionTier(userId: string, tier: "free" | "pro"): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, subscriptionTier: tier };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async incrementUserScoreUsage(userId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const today = new Date();
    const lastReset = new Date(user.lastScoreReset || 0);
    
    // Reset daily count if it's a new day
    let dailyScoresUsed = user.dailyScoresUsed || 0;
    if (today.toDateString() !== lastReset.toDateString()) {
      dailyScoresUsed = 0;
    }
    
    const updatedUser = {
      ...user,
      dailyScoresUsed: dailyScoresUsed + 1,
      lastScoreReset: today,
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async resetUserDailyScores(userId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = {
      ...user,
      dailyScoresUsed: 0,
      lastScoreReset: new Date(),
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getAllMarkets(): Promise<Market[]> {
    return Array.from(this.markets.values()).filter(market => market.isActive);
  }

  async getMarket(id: string): Promise<Market | undefined> {
    return this.markets.get(id);
  }

  async getMarketByTicker(ticker: string): Promise<Market | undefined> {
    return Array.from(this.markets.values()).find(market => market.ticker === ticker);
  }

  async createMarket(insertMarket: InsertMarket): Promise<Market> {
    const id = randomUUID();
    const market: Market = {
      id,
      ticker: insertMarket.ticker,
      title: insertMarket.title,
      description: insertMarket.description || null,
      category: insertMarket.category || null,
      currentPrice: insertMarket.currentPrice || null,
      fairValue: insertMarket.fairValue || null,
      predictWiseScore: insertMarket.predictWiseScore || null,
      volume: insertMarket.volume || null,
      traders: insertMarket.traders || null,
      endDate: insertMarket.endDate || null,
      priceChange: insertMarket.priceChange || null,
      openInterest: insertMarket.openInterest || null,
      valueAssessment: insertMarket.valueAssessment || null,
      isActive: true,
      lastUpdated: new Date(),
      priceHistory: insertMarket.priceHistory || null,
    };
    this.markets.set(id, market);
    return market;
  }

  async updateMarket(id: string, updates: Partial<Market>): Promise<Market> {
    const market = this.markets.get(id);
    if (!market) throw new Error("Market not found");
    
    const updatedMarket = {
      ...market,
      ...updates,
      lastUpdated: new Date(),
    };
    this.markets.set(id, updatedMarket);
    return updatedMarket;
  }

  async getMarketsByCategory(category: string): Promise<Market[]> {
    return Array.from(this.markets.values()).filter(
      market => market.category === category && market.isActive
    );
  }

  async searchMarkets(query: string): Promise<Market[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.markets.values()).filter(
      market => 
        market.isActive && (
          market.title?.toLowerCase().includes(lowercaseQuery) ||
          market.description?.toLowerCase().includes(lowercaseQuery) ||
          market.ticker?.toLowerCase().includes(lowercaseQuery)
        )
    );
  }

  async recordScoreUsage(insertUsage: InsertScoreUsage): Promise<ScoreUsage> {
    const id = randomUUID();
    const usage: ScoreUsage = {
      ...insertUsage,
      id,
      timestamp: new Date(),
    };
    this.scoreUsage.set(id, usage);
    return usage;
  }

  async getUserScoreUsageToday(userId: string): Promise<number> {
    const today = new Date().toDateString();
    return Array.from(this.scoreUsage.values()).filter(
      usage => 
        usage.userId === userId && 
        new Date(usage.timestamp || 0).toDateString() === today
    ).length;
  }
}

export const storage = new MemStorage();
