import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('STRIPE_SECRET_KEY not found. Stripe functionality will be disabled.');
}

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-07-30.basil",
}) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.json({ user: { id: user.id, email: user.email, username: user.username, subscriptionTier: user.subscriptionTier } });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({ 
        user: { 
          id: user.id, 
          email: user.email, 
          username: user.username, 
          subscriptionTier: user.subscriptionTier,
          dailyScoresUsed: user.dailyScoresUsed || 0
        } 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Markets routes
  app.get("/api/markets", async (req, res) => {
    try {
      const { category, search, limit = "50" } = req.query;
      let markets;
      
      if (search) {
        markets = await storage.searchMarkets(search as string);
      } else if (category) {
        markets = await storage.getMarketsByCategory(category as string);
      } else {
        markets = await storage.getAllMarkets();
      }
      
      // Limit results
      const limitNum = parseInt(limit as string);
      const limitedMarkets = markets.slice(0, limitNum);
      
      res.json({ markets: limitedMarkets });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/markets/:id", async (req, res) => {
    try {
      const market = await storage.getMarket(req.params.id);
      if (!market) {
        return res.status(404).json({ message: "Market not found" });
      }
      res.json({ market });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Score usage endpoint
  app.post("/api/use-score", async (req, res) => {
    try {
      const { userId, marketId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user has remaining scores
      if (user.subscriptionTier === "free") {
        const today = new Date();
        const lastReset = new Date(user.lastScoreReset || 0);
        let dailyScoresUsed = user.dailyScoresUsed || 0;
        
        // Reset if new day
        if (today.toDateString() !== lastReset.toDateString()) {
          dailyScoresUsed = 0;
        }
        
        if (dailyScoresUsed >= 10) {
          return res.status(403).json({ message: "Daily score limit reached. Upgrade to Pro for unlimited scores." });
        }
      }
      
      // Record usage and increment counter
      await storage.recordScoreUsage({ userId, marketId });
      const updatedUser = await storage.incrementUserScoreUsage(userId);
      
      res.json({ 
        success: true, 
        dailyScoresUsed: updatedUser.dailyScoresUsed,
        subscriptionTier: updatedUser.subscriptionTier 
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stats endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const markets = await storage.getAllMarkets();
      const activeMarkets = markets.length;
      const goodValueCount = markets.filter(m => m.valueAssessment === "good_value").length;
      const avgScore = markets.reduce((sum, m) => sum + parseFloat(m.predictWiseScore || "0"), 0) / markets.length;
      
      res.json({
        activeMarkets,
        goodValueCount,
        avgScore: Math.round(avgScore * 10) / 10,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Kalshi sync endpoint (for admin use)
  app.post("/api/sync-markets", async (req, res) => {
    try {
      // This would typically fetch from Kalshi API and update our database
      // For now, we'll create some sample markets
      const sampleMarkets = [
        {
          ticker: "FED-JUNE-2025-CUT",
          title: "Will the Fed cut rates by 0.25% in June 2025?",
          description: "Federal Reserve monetary policy decision for June FOMC meeting",
          category: "Economics",
          currentPrice: "68",
          fairValue: "72",
          predictWiseScore: "7.4",
          volume: "3200000",
          traders: 1834,
          endDate: new Date("2025-06-18"),
          priceChange: "3",
          openInterest: "1200000",
          valueAssessment: "good_value",
        },
        {
          ticker: "BTC-150K-2025",
          title: "Will Bitcoin reach $150,000 by end of 2025?",
          description: "Bitcoin price prediction following recent market momentum",
          category: "Crypto",
          currentPrice: "45",
          fairValue: "52",
          predictWiseScore: "8.4",
          volume: "6800000",
          traders: 3942,
          endDate: new Date("2025-12-31"),
          priceChange: "-3",
          openInterest: "2100000",
          valueAssessment: "good_value",
        },
        {
          ticker: "TESLA-Q2-2025-DELIVERY",
          title: "Will Tesla deliver 500K+ vehicles in Q2 2025?",
          description: "Tesla quarterly delivery numbers for Q2 2025",
          category: "Tech",
          currentPrice: "73",
          fairValue: "69",
          predictWiseScore: "6.8",
          volume: "2400000",
          traders: 1967,
          endDate: new Date("2025-07-02"),
          priceChange: "6",
          openInterest: "780000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "NBA-CHAMPIONSHIP-2025",
          title: "Which team will win the 2025 NBA Championship?",
          description: "Multiple outcome market: Celtics (32¢), Nuggets (28¢), Warriors (18¢), Lakers (15¢), Other (7¢)",
          category: "Sports",
          currentPrice: "32",
          fairValue: "29",
          predictWiseScore: "7.8",
          volume: "4200000",
          traders: 8967,
          endDate: new Date("2025-06-20"),
          priceChange: "4",
          openInterest: "1850000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "AI-BREAKTHROUGH-2025",
          title: "Which company will achieve next major AI breakthrough?",
          description: "Multiple outcome market: OpenAI (35¢), Google (28¢), Anthropic (18¢), Meta (12¢), Other (7¢)",
          category: "Tech",
          currentPrice: "35",
          fairValue: "32",
          predictWiseScore: "7.5",
          volume: "5400000",
          traders: 9876,
          endDate: new Date("2025-12-31"),
          priceChange: "8",
          openInterest: "1900000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "NVIDIA-STOCK-200",
          title: "Will NVIDIA stock hit $200 in 2025?",
          description: "NVIDIA stock price prediction amid AI boom",
          category: "Tech",
          currentPrice: "82",
          fairValue: "79",
          predictWiseScore: "6.1",
          volume: "4300000",
          traders: 2891,
          endDate: new Date("2025-12-31"),
          priceChange: "15",
          openInterest: "1600000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "ELECTION-2028-PARTY",
          title: "Which party will win the 2028 Presidential Election?",
          description: "Multiple outcome market: Republican (42¢), Democrat (38¢), Independent/Third Party (20¢)",
          category: "Politics",
          currentPrice: "42",
          fairValue: "45",
          predictWiseScore: "8.1",
          volume: "9200000",
          traders: 15432,
          endDate: new Date("2028-11-07"),
          priceChange: "-2",
          openInterest: "3800000",
          valueAssessment: "good_value",
        },
        {
          ticker: "OIL-PRICE-90-2025",
          title: "Will oil prices reach $90/barrel in 2025?",
          description: "Crude oil price prediction amid geopolitical tensions",
          category: "Economics",
          currentPrice: "58",
          fairValue: "62",
          predictWiseScore: "7.6",
          volume: "3400000",
          traders: 2134,
          endDate: new Date("2025-12-31"),
          priceChange: "-5",
          openInterest: "1100000",
          valueAssessment: "good_value",
        },
        {
          ticker: "OPENAI-GPT5-2025",
          title: "Will OpenAI release GPT-5 in 2025?",
          description: "Next-generation AI model release prediction",
          category: "Tech",
          currentPrice: "73",
          fairValue: "69",
          predictWiseScore: "6.8",
          volume: "2700000",
          traders: 3456,
          endDate: new Date("2025-12-31"),
          priceChange: "7",
          openInterest: "950000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "RECESSION-US-2025",
          title: "Will US enter recession in 2025?",
          description: "US economic recession prediction for 2025",
          category: "Economics",
          currentPrice: "34",
          fairValue: "39",
          predictWiseScore: "8.1",
          volume: "5200000",
          traders: 6789,
          endDate: new Date("2025-12-31"),
          priceChange: "-8",
          openInterest: "1800000",
          valueAssessment: "good_value",
        },
        {
          ticker: "SPACEX-MARS-2025",
          title: "Will SpaceX launch crewed mission to Mars in 2025?",
          description: "SpaceX Mars mission timeline prediction",
          category: "Tech",
          currentPrice: "22",
          fairValue: "28",
          predictWiseScore: "8.9",
          volume: "1600000",
          traders: 2987,
          endDate: new Date("2025-12-31"),
          priceChange: "-12",
          openInterest: "580000",
          valueAssessment: "good_value",
        },
        {
          ticker: "AMAZON-STOCK-250",
          title: "Will Amazon stock hit $250 in 2025?",
          description: "Amazon stock price prediction for 2025",
          category: "Tech",
          currentPrice: "78",
          fairValue: "74",
          predictWiseScore: "6.3",
          volume: "3100000",
          traders: 2156,
          endDate: new Date("2025-12-31"),
          priceChange: "11",
          openInterest: "1200000",
          valueAssessment: "overpriced",
        },
        {
          ticker: "WORLD-CUP-2026-WINNER",
          title: "Which country will win the 2026 World Cup?",
          description: "Multiple outcome market: Brazil (18¢), France (16¢), Argentina (15¢), England (12¢), Spain (11¢), Other (28¢)",
          category: "Sports",
          currentPrice: "18",
          fairValue: "21",
          predictWiseScore: "8.6",
          volume: "6800000",
          traders: 12456,
          endDate: new Date("2026-07-19"),
          priceChange: "-4",
          openInterest: "2400000",
          valueAssessment: "good_value",
        },
        {
          ticker: "CLIMATE-PARIS-2025",
          title: "Will global CO2 emissions drop 5% in 2025?",
          description: "Global climate action and emissions reduction prediction",
          category: "Science",
          currentPrice: "31",
          fairValue: "36",
          predictWiseScore: "8.3",
          volume: "1200000",
          traders: 1543,
          endDate: new Date("2025-12-31"),
          priceChange: "-15",
          openInterest: "420000",
          valueAssessment: "good_value",
        },
        {
          ticker: "HOUSING-CRASH-2025",
          title: "Will US housing prices drop 15%+ in 2025?",
          description: "US real estate market crash prediction",
          category: "Economics",
          currentPrice: "41",
          fairValue: "46",
          predictWiseScore: "7.9",
          volume: "4100000",
          traders: 3890,
          endDate: new Date("2025-12-31"),
          priceChange: "-7",
          openInterest: "1500000",
          valueAssessment: "good_value",
        }
      ];

      for (const marketData of sampleMarkets) {
        const existing = await storage.getMarketByTicker(marketData.ticker);
        if (!existing) {
          await storage.createMarket(marketData);
        }
      }

      res.json({ message: "Markets synced successfully", count: sampleMarkets.length });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stripe subscription routes
  if (stripe) {
    app.post('/api/create-subscription', async (req, res) => {
      try {
        const { userId } = req.body;
        
        const user = await storage.getUser(userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }

        if (user.stripeSubscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
          
          return res.json({
            subscriptionId: subscription.id,
            clientSecret: null, // Will be handled by existing subscription
          });
        }
        
        let customerId = user.stripeCustomerId;
        
        if (!customerId) {
          const customer = await stripe.customers.create({
            email: user.email,
            name: user.username,
          });
          customerId = customer.id;
        }

        if (!process.env.STRIPE_PRICE_ID) {
          return res.status(500).json({ message: "Stripe price ID not configured" });
        }

        const subscription = await stripe.subscriptions.create({
          customer: customerId,
          items: [{
            price: process.env.STRIPE_PRICE_ID,
          }],
          payment_behavior: 'default_incomplete',
          expand: ['latest_invoice.payment_intent'],
        });

        await storage.updateUserStripeInfo(user.id, customerId, subscription.id);
        
        const invoice = subscription.latest_invoice as any;
        const paymentIntent = invoice.payment_intent;
    
        res.json({
          subscriptionId: subscription.id,
          clientSecret: paymentIntent.client_secret,
        });
      } catch (error: any) {
        res.status(400).json({ message: error.message });
      }
    });

    app.post('/api/cancel-subscription', async (req, res) => {
      try {
        const { userId } = req.body;
        
        const user = await storage.getUser(userId);
        if (!user || !user.stripeSubscriptionId) {
          return res.status(404).json({ message: "No active subscription found" });
        }

        await stripe.subscriptions.cancel(user.stripeSubscriptionId);
        await storage.updateUserSubscriptionTier(userId, "free");
        
        res.json({ message: "Subscription cancelled successfully" });
      } catch (error: any) {
        res.status(400).json({ message: error.message });
      }
    });
  } else {
    // Stripe not configured - return error for subscription endpoints
    app.post('/api/create-subscription', (req, res) => {
      res.status(500).json({ message: "Stripe not configured. Please set STRIPE_SECRET_KEY environment variable." });
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}
